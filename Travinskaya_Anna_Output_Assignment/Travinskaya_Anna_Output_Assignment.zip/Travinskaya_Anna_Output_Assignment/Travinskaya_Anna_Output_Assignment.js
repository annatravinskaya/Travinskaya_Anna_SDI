//Anna Travinskaya
// Scalable Data Infrastructures 201510-01 Travinskaya_Anna_Output_Assignment //
// 5.10.2015//

var myPlaceOfLiving = "Switzerland"; // declared and defined my string variable //
var numberOfYears = 6; // declared and defined my number variable //
var swissNationality = false; // declared and defined my Boolean variable //


document.write(" Hello, I live in " + myPlaceOfLiving + " for " + numberOfYears + " years. "); // Concatenated output for my string and number variables.//

document.write( numberOfYears + " years is a lot. "); // Concatenated output for my number variable. //

document.write("However, it is " + swissNationality + " to assume that I have a Swiss nationality."); // Concatenated output for my Boolean variable. //


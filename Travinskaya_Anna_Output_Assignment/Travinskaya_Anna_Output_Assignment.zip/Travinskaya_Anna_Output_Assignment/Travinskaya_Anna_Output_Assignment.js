/** Anna Travinskaya
* Scalable Data Infrastructures 201510-01 Output Assignment
* 5.10.2015
 * */

var myPlaceOfLiving = "Switzerland"; // declared and defined my string variable
var numberOfYears = 6; // declared and defined my number variable
var swissNationality = false; // declared and defined my Boolean variable


console.log(" Hello, I live in " + myPlaceOfLiving + " for " + numberOfYears + " years. "); // Concatenated output for my string and number variables.

console.log( numberOfYears + " years is a lot. "); // Concatenated output for my number variable.

console.log("However, it is " + swissNationality + " to assume that I have a Swiss nationality."); // Concatenated output for my Boolean variable.

